<?php
$config = [
	'name' => 'Afrikaans',
	'locale' => 'af',
	'author' => 'Mautic Translators',
];

return $config;