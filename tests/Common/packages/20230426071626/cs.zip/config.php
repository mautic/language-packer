<?php
$config = [
	'name' => 'Czech',
	'locale' => 'cs',
	'author' => 'Mautic Translators',
];

return $config;